// user 用户

export const SET_LOGIN_NAME = 'SET_LOGIN_NAME'; // 设置登录状态
export const SET_LOGIN_TYPE = 'SET_LOGIN_TYPE'; // 设置登录用户名
